﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Clients_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientsController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetClients()
        {
            var clients = new List<Client>
            {
                new Client { Name = "Alice Johnson", Nationality = "American", Occupation= "Engineer", Email="alice@example.com"},
                new Client { Name = "Carlos García", Nationality = "Mexican", Occupation = "Teacher", Email = "carlos@example.com" },
                new Client { Name = "Marie Dubois", Nationality = "French", Occupation = "Artist", Email = "marie@example.com" }
            };

            return Ok(clients);
        }

        public class Client
        {
            public string Name { get; set; }
            public string Nationality { get; set; }
            public string Occupation { get; set; }
            public string Email { get; set; }
        }
    }
}
